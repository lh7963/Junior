This directory contains the SDL2 files needed for running on windows.
You will not need to change anything in here.
You probably don't even need to look at anything in here.
